const express = require("express");
const userController = require("../controllers/userController");
const authController = require("./../controllers/authController");
const reviewUsersRouter = require("./../routes/reviewUsersRoutes");
const User = require("../models/userModel");

// const reviewDoctor = require("../models/reviewDoctorsModel");

const router = express.Router();
router.get("/homePage", (req, res) => {
  res.send("Welcome to the homepage!");
});

router.post("/signup", authController.signup(User));
router.post("/login", authController.login(User));
router.post("/forgotPassword", authController.forgotPassword(User));
router.patch("/resetPassword", authController.resetPassword(User));

router.use(authController.protect);
router.get(
  "/me",
  authController.restrictTo("Doctor"),
  userController.getMe,
  userController.getUser
);
router.patch("/updateMyPassword", authController.updatePassword(User));
router.patch("/udpateMe", userController.updateMe);
router.delete("/deleteMe", userController.deleteMe);

router.route("/").get(authController.protect, userController.getAllUsers);
// .post(userController.createUser);

router
  .route("/:id")
  .get(userController.getUser)
  .patch(userController.updateUser)
  .delete(userController.deleteUser);

router.use("/:userId/reviews", reviewUsersRouter);

module.exports = router;
