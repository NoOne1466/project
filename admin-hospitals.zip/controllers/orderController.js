const { PaymentGateway, paymobAPI } = require("../services/PaymentGetaway.js");
const Order = require("../models/orderModel");
const Doctor = require("../models/doctorModel");
const User = require("../models/userModel.js");

const Appointment = require("../models/appointmentModel.js");

const catchAsync = require("../utils/catchAsync");
const APIFeatures = require("../utils/apiFeatures");
const AppError = require("../utils/appError");
const fs = require("fs");

exports.getAll = catchAsync(async (req, res, next) => {
  const features = new APIFeatures(Order.find(), req.query)
    .filter()
    .sort()
    .limitFields()
    .paginate();

  const orders = await features.query;

  res.status(200).json({
    status: "success",
    results: orders.length,
    data: {
      orders,
    },
  });
});

exports.getMyOrders = catchAsync(async (req, res, next) => {
  const orders = await Order.find({ user: req.user._id });

  res.status(200).json({
    status: "success",
    results: orders.length,
    data: {
      orders,
    },
  });
});

exports.createOrder = catchAsync(async (req, res, next) => {
  // add how many patient need to appoint
  const doctor = await Doctor.findById(req.body.doctorId);

  if (!doctor) {
    throw new AppError("No doctor found with that ID", 404);
  }
  const { startTime } = req.body;

  const parsedStartTime = new Date(startTime);
  const parsedEndTime = new Date(parsedStartTime.getTime() + 20 * 60000);

  const isAvailable = doctor.availableSlots.some((slot) => {
    return (
      slot.startTime.getTime() <= parsedStartTime.getTime() &&
      slot.endTime.getTime() >= parsedEndTime.getTime()
    );
  });

  // If the slot is not available, find the next available slot
  if (!isAvailable) {
    const nextAvailableSlot = doctor.availableSlots.find((slot) => {
      return slot.startTime.getTime() > parsedEndTime.getTime();
    });

    if (!nextAvailableSlot) {
      return res
        .status(400)
        .json({ status: "error", message: "No available slots" });
    }

    // Update the start and end time to the next available slot
    parsedStartTime.setTime(nextAvailableSlot.startTime.getTime());
    parsedEndTime.setTime(parsedStartTime.getTime() + 20 * 60000); // 20 minutes later
  }

  const order = new Order({
    user: req.user._id,
    doctor: doctor._id,
    priceInCents: doctor.priceOfConsultationInCents || 10000,
    isPaid: false,
    startTime: parsedStartTime,
    endTime: parsedEndTime,
  });

  const paymentGateway = new PaymentGateway(
    paymobAPI,
    process.env.API_KEY,
    process.env.INTEGRATION_ID
  );
  await paymentGateway.getToken();

  const paymobOrder = await paymentGateway.createOrder({
    id: order._id,
    priceInCents: order.priceInCents,
    name: doctor.firstName,
    description: "Consultation",
  });

  const paymentToken = await paymentGateway.createPaymentGateway({
    uEmail: req.user.email,
    uFirstName: req.user.firstName,
    uLastName: req.user.lastName,
    uPhoneNumber: "NA",
  });
  order.orderId = paymobOrder.id;

  await order.save();

  const index = doctor.availableSlots.findIndex((slot) => {
    return (
      parsedStartTime.getTime() >= slot.startTime.getTime() &&
      parsedEndTime.getTime() <= slot.endTime.getTime()
    );
  });

  // Check if the appointment falls within any slot
  if (index !== -1) {
    // Get the slot where the appointment is booked
    const bookedSlot = doctor.availableSlots[index];

    // Calculate the end time for the first slot (before the booked appointment)
    const firstSlotEndTime = new Date(parsedStartTime);
    firstSlotEndTime.setMinutes(firstSlotEndTime.getMinutes());

    // Create the first slot (before the booked appointment)
    const firstSlot = {
      startTime: bookedSlot.startTime,
      endTime: firstSlotEndTime,
    };

    // Calculate the start time for the second slot (after the booked appointment)
    const secondSlotStartTime = new Date(parsedEndTime);
    secondSlotStartTime.setMinutes(secondSlotStartTime.getMinutes() + 1);

    // Create the second slot (after the booked appointment)
    const secondSlot = {
      startTime: secondSlotStartTime,
      endTime: bookedSlot.endTime,
    };

    // Replace the booked slot with the two new slots
    doctor.availableSlots.splice(index, 1, firstSlot, secondSlot);
  }

  // Save the updated doctor document
  await doctor.save({ validateBeforeSave: false });

  await User.findByIdAndUpdate(req.user._id, {
    $push: { orders: order._id },
  });
  await Doctor.findByIdAndUpdate(req.body.doctorId, {
    $push: { orders: order._id },
  });

  const paymentURL = process.env.IFRAME_URL.replace("{{TOKEN}}", paymentToken);

  res.status(201).json({
    status: "success",
    data: paymentURL,
  });
});

exports.refund = catchAsync(async (req, res, next) => {
  // update appointment to cancel
  const order = await Order.findById(req.params.id);
  if (!order) {
    throw new AppError("No order found with that ID", 404);
  }

  const paymentGateway = new PaymentGateway(
    paymobAPI,
    process.env.API_KEY,
    process.env.INTEGRATION_ID
  );

  await paymentGateway.getToken();

  const refund = await paymentGateway.createRufund(
    order.transactionId,
    order.priceInCents
  );

  res.status(200).json({
    status: "success",
    data: refund,
  });
});

exports.webhook = catchAsync(async (req, res, next) => {
  const paymobAns = req.body;
  const hmac = req.query.hmac;

  if (!hmac) throw new AppError("HMAC is required", 400);
  if (!paymobAns) throw new AppError("Invalid request", 400);
  if (!PaymentGateway.verifyHmac(paymobAns, hmac, process.env.HMAC_SECRET))
    throw new AppError("Invalid HMAC", 400);
  console.log("asdasdsadasdasd ", paymobAns);

  if (paymobAns.type !== "TRANSACTION") {
    return res.status(200).json({
      status: "success",
    });
  }
  if (paymobAns.obj.success !== true)
    throw new AppError("Transaction failed", 400);

  const orderId = paymobAns?.obj?.order?.merchant_order_id;

  const order = await Order.findByIdAndUpdate(
    orderId,
    {
      isPaid: true,
      transactionId: paymobAns?.obj?.id,
      paidAt: Date.now(),
    },
    {
      new: true,
      runValidators: true,
    }
  );
  console.log(order);

  const appointment = new Appointment({
    user: order.user,
    doctor: order.doctor,
    startTime: order.startTime,
    endTime: order.endTime,
    status: "pending", // Set appointment status to 'pending'
  });

  console.log(appointment);
  await appointment.save();

  return res.status(200).json({
    status: "success",
  });
});
