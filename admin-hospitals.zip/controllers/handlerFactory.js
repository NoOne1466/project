const catchAsync = require("./../utils/catchAsync");
const AppError = require("./../utils/appError");
const APIFeatures = require("./../utils/apiFeatures");
// const Doctor = require("../models/doctorModel");
// const User = require("../models/userModel");

const filterObj = (obj, ...allowedFields) => {
  const newObj = {};
  Object.keys(obj).forEach((el) => {
    if (allowedFields.includes(el)) newObj[el] = obj[el];
  });
  return newObj;
};

exports.deleteOne = (Model) =>
  catchAsync(async (req, res, next) => {
    const doc = await Model.findByIdAndDelete(req.params.id);

    if (!doc) {
      return next(new AppError("No document found with that ID", 404));
    }

    // if (calculateRatings) {
    //   await calculateRatings(doc.hospital);
    // }

    res.status(204).json({
      status: "success",
      data: null,
    });
  });

exports.updateOne = (Model) =>
  catchAsync(async (req, res, next) => {
    const doc = await Model.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });

    if (!doc) {
      return next(new AppError("No document found with that ID", 404));
    }

    res.status(200).json({
      status: "success",
      data: {
        data: doc,
      },
    });
  });

exports.createOne = (Model) =>
  catchAsync(async (req, res, next) => {
    // console.log(req.user);
    const doc = await Model.create(req.body);
    // console.log(req.body);

    res.status(201).json({
      status: "success",
      data: {
        data: doc,
      },
    });
  });

exports.getOne = (Model, popOptions) =>
  catchAsync(async (req, res, next) => {
    let query = Model.findById(req.params.id);

    if (popOptions) query = query.populate(popOptions);
    // console.log(popOptions);
    const doc = await query;

    if (!doc) {
      return next(new AppError("No document found with that ID", 404));
    }

    res.status(200).json({
      status: "success",
      data: {
        data: doc,
      },
    });
  });

exports.getAll = (Model) =>
  catchAsync(async (req, res, next) => {
    // To allow for nested GET reviews on doc or user (hack)
    let filter = {};
    if (req.params.doctorId) filter = { doctor: req.params.doctorId };
    if (req.params.userId) filter = { user: req.params.userId };

    const features = new APIFeatures(Model.find(filter), req.query)
      .filter()
      .sort()
      .limitFields()
      .paginate();
    // const doc = await features.query.explain();
    const doc = await features.query;

    // SEND RESPONSE
    res.status(200).json({
      status: "success",
      results: doc.length,
      data: {
        data: doc,
      },
    });
  });

exports.getMe = (req, res, next) => {
  if (req.userModel === "User") {
    console.log(req.userModel);
    req.params.id = req.user.id;
    next();
  }
  if (req.userModel === "Doctor") {
    console.log(req.userModel);
    req.params.id = req.doctor.id;
    next();
  }
};

exports.updateMe = (Model) =>
  catchAsync(async (req, res, next) => {
    if (req.body.password || req.body.passwordConfirm) {
      // 1) Create error if user POSTs password data
      return next(
        new AppError(
          "This route is not for password updates. Please use /updateMyPassword.",
          400
        )
      );
    }

    // 2) Filtered out unwanted fields names that are not allowed to be updated
    const filteredBody = filterObj(
      req.body,
      "firstName",
      "lastName",
      "email",
      "photo",
      "availableSlots"
    );
    // const filteredBody = req.body
    // if (req.file) filteredBody.photo = req.file.filename;

    // 3) Update user document
    console.log(req.model);
    const updatedUser = await Model.findByIdAndUpdate(
      req.model.id,
      filteredBody,
      {
        new: true,
        runValidators: true,
      }
    );
    if (!updatedUser) {
      return next(
        new AppError(
          "The logged in user does not have permision for this route"
        )
      );
    }

    res.status(200).json({
      status: "success",
      data: {
        user: updatedUser,
      },
    });
  });

exports.deleteMe = (Model) =>
  catchAsync(async (req, res, next) => {
    const user = await Model.findByIdAndUpdate(req.model.id, { active: false });
    if (!user) {
      return next(
        new AppError(
          "The logged in user does not have permision for this route"
        )
      );
    }

    res.status(204).json({
      status: "success",
      data: null,
    });
  });

exports.homePage = (req, res) => {
  res.send("Welcome to the homepage!");
};
