const ReviewHospitals = require("../models/reviewHospitalModel");
const Hospital = require("../models/hospitalModel");
const factory = require("./handlerFactory");

exports.setDoctorUserIds = (req, res, next) => {
  // Allow nested routes
  if (!req.user) {
    if (!req.body.user) req.body.user = req.doctor.id;
  }
  if (!req.body.user) req.body.user = req.user.id;
  next();
};

exports.getAllReviews = factory.getAll(ReviewHospitals);
exports.getReview = factory.getOne(ReviewHospitals);
exports.createReview = factory.createOne(ReviewHospitals);
exports.updateReview = factory.updateOne(ReviewHospitals);
exports.deleteReview = factory.deleteOne(ReviewHospitals);
