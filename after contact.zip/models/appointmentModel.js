const mongoose = require("mongoose");

const appointmentSchema = new mongoose.Schema({
  doctor: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Doctor",
  },
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
  },
  startTime: Date,
  endTime: Date,
  status: {
    type: String,
    enum: ["pending", "accepted", "refused", "canceled", "completed"],
    default: "pending",
  },
});

const Appointment = mongoose.model("Appointment", appointmentSchema);

module.exports = Appointment;
