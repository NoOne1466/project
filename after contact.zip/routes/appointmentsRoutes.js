const express = require("express");
const appointmentController = require("../controllers/appointmentController");
const authController = require("./../controllers/authController");

const router = express.Router();

// router.use(authController.protect);

router.use(authController.protect);
router
  .route("/")
  .get(appointmentController.getAllAppointments)
  // .post(appointmentController.bookAppointment);

router
  .route("/getbyid/:id")
  .post(appointmentController.updateAppointmentStatus)
  .delete(appointmentController.cancelAppointment)
  .get(appointmentController.getappointmentById);

router
  .route("/getCurrentAppointmentsForDoctor")
  .get(appointmentController.getCurrentDoctorAppointment);

router
  .route("/getCurrentAppointmentsForUser")
  .get(appointmentController.getCurrentUserAppointment);

module.exports = router;
