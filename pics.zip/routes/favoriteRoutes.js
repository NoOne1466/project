const express = require("express");
const authController = require("../controllers/authController");
const favoriteController = require("../controllers/favoriteController");

const router = express.Router();

router.use(authController.protect);

router.route("/").get(favoriteController.getAllFavorites);
router.route("/add-to-favorites").post(favoriteController.addToFavorites);
router
  .route("/remove-from-favorites")
  .delete(favoriteController.removeFromFavorites);

module.exports = router;
