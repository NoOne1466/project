const catchAsync = require("./../utils/catchAsync");
const APIFeatures = require("./../utils/apiFeatures");
const Doctor = require("./../models/doctorModel");
const Appointment = require("./../models/appointmentModel.js");
const AppError = require("./../utils/appError");
const stripe = require("stripe");
const factory = require("./handlerFactory.js");

exports.getAllAppointments = async (req, res, next) => {
  try {
    const appointments = await Appointment.find();
    res.status(200).json({
      status: "success",
      data: {
        appointments,
      },
    });
  } catch (err) {
    return next(
      new AppError(
        "There was an error getting the appointments. Try again later!"
      ),
      500
    );
  }
};

exports.bookAppointment = async (req, res, next) => {
  try {
    const { doctorId, startTime, endTime } = req.body;
    // console.log(req.user);
    const userId = req.user.id;
    // Find the doctor by ID
    const doctor = await Doctor.findById(doctorId);

    // Check if the doctor exists
    if (!doctor) {
      return res
        .status(404)
        .json({ status: "error", message: "Doctor not found" });
    }

    // Check if the requested time slot is available
    const isAvailable = doctor.availableSlots.some((slot) => {
      return (
        slot.startTime.getTime() === new Date(startTime).getTime() &&
        slot.endTime.getTime() === new Date(endTime).getTime()
      );
    });

    if (!isAvailable) {
      return res.status(400).json({
        status: "error",
        message: "Requested time slot is not available",
      });
    }

    // Create a new appointment
    const appointment = new Appointment({
      doctor: doctorId,
      user: userId,
      startTime: new Date(startTime),
      endTime: new Date(endTime),
      status: "pending",
    });

    // Save the appointment
    await appointment.save();

    // Create a payment intent in Stripe

    // Update doctor's available time slots (mark as booked)
    doctor.availableSlots = doctor.availableSlots.filter(
      ({ startTime: slotStartTime, endTime: slotEndTime }) => {
        const startTimesMatch =
          slotStartTime.getTime() === new Date(startTime).getTime();
        const endTimesMatch =
          slotEndTime.getTime() === new Date(endTime).getTime();
        return !startTimesMatch || !endTimesMatch;
      }
    );

    // Save the updated doctor document
    await doctor.save({ validateBeforeSave: false });

    res.status(201).json({ status: "success", data: { appointment } });
  } catch (error) {
    return next(
      new AppError(
        "There was an error booking your appointment. Try again later!"
      ),
      500
    );
  }
};

exports.updateAppointmentStatus = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    // Find the appointment by ID
    const appointment = await Appointment.findById(id);
    // Check if the signed in user is a doctor
    // console.log(req.doctor);
    if (req.userModel !== "Doctor")
      return next(
        new AppError(
          "The signed in user is not authorized to change the statu of the appointment",
          401
        )
      );
    // console.log(appointment.doctor.toHexString());
    // console.log(req.doctor.id);

    if (req.doctor.id !== appointment.doctor.toHexString()) {
      return next(
        new AppError(
          "The doctor signed in is not related to this appointment",
          401
        )
      );
    }
    // Update the status
    appointment.status = status;

    await appointment.save();

    res.status(200).json({
      status: "success",
      data: {
        appointment,
      },
    });
  } catch (error) {
    return next(
      new AppError(
        "There was an error updating your appointment. Try again later!"
      ),
      500
    );
  }
};

exports.cancelAppointment = async (req, res, next) => {
  try {
    const appointmentId = req.params.id;

    // Find the appointment in the database
    const appointment = await Appointment.findById(appointmentId);

    // Check if the appointment exists
    if (!appointment) {
      return new AppError(
        "The id provided is not related to an appointment",
        401
      );
    }

    // Check if the user is authorized to cancel the appointment

    if (appointment.user.toHexString() !== req.user.id) {
      return new AppError(
        "The user signed in is not related to this appointment",
        401
      );
    }

    // Update the appointment from the database
    const updatedAppointment = await Appointment.updateOne(
      { _id: appointmentId, user: req.user.id }, // Criteria: Find the appointment by its ID and user
      { status: "canceled" } // Update: Set the status field to "canceled"
    );

    // Send success response
    res.status(200).json({ message: "Appointment cancelled successfully" });
  } catch (error) {
    // Handle errors
    return next(
      new AppError(
        "There was an error canceling your appointment. Try again later!"
      ),
      500
    );
  }
};

exports.getappointmentById = async (req, res, next) => {
  try {
    // Find the appointment by its ID
    const appointment = await Appointment.findById(req.params.id);

    // Check if the appointment exists
    if (!appointment) {
      return next(
        new AppError("There is no appointment with the provided ID"),
        404
      );
    }

    // If the appointment exists, return it
    res.status(200).json({ status: "success", data: { appointment } });
  } catch (error) {
    return next(
      new AppError(
        "There was an error getting the appointment, Please try again later!"
      ),
      404
    );
  }
};

exports.getCurrentDoctorAppointment = async (req, res, next) => {
  try {
    // Find appointments associated with the doctor's ID
    // console.log(req.doctor);
    const appointments = await Appointment.find({ doctor: req.doctor.id });

    // Check if appointments are found
    if (!appointments || appointments.length === 0) {
      return next(
        new AppError("There are no appointments for the current doctor"),
        404
      );
    }

    // If appointments are found, send them in the response
    res.status(200).json({ status: "success", data: { appointments } });
  } catch (error) {
    // Handle errors
    return next(
      new AppError("There was an error getting your appointments"),
      404
    );
  }
};

exports.getCurrentUserAppointment = async (req, res, next) => {
  try {
    // Find appointments associated with the doctor's ID
    const appointments = await Appointment.find({ user: req.user.id });
    // console.log(req.user)
    // Check if appointments are found
    if (!appointments || appointments.length === 0) {
      return next(
        new AppError("There are no appointments for the current user"),
        404
      );
    }

    // If appointments are found, send them in the response
    res.status(200).json({ status: "success", data: { appointments } });
  } catch (error) {
    // Handle errors
    return next(
      new AppError("There where an error getting your appointments"),
      404
    );
  }
};
