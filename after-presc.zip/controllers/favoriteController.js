const Favorite = require("../models/favoriteModel");
const AppError = require("./../utils/appError");
const factory = require("./handlerFactory.js");
const Doctor = require("../models/doctorModel.js");
exports.getAllFavorites = factory.getAll(Favorite);

exports.addToFavorites = async (req, res, next) => {
  try {
    const { doctorId } = req.body;

    const userId = req.user.id;

    // // check if there's a doctor
    // const existingDoctor = await Doctor.findById(doctorId);
    // console.log(existingDoctor);
    // if (!existingDoctor)
    //   return next(new AppError("Doctor is not in our DB", 400));

    // Check if the doctor is already in favorites
    const existingFavorite = await Favorite.findOne({
      user: userId,
      doctor: doctorId,
    });

    if (existingFavorite) {
      // Doctor is already in favorites, you may want to remove it or handle accordingly
      return next(new AppError("Doctor is already in favorites", 400));
    }

    // Add the doctor to favorites
    const favorite = await Favorite.create({ user: userId, doctor: doctorId });

    res.status(201).json({ status: "success", data: favorite });
  } catch {
    next(new AppError("Doctor is not difined", 404));
  }
};

exports.removeFromFavorites = async (req, res, next) => {
  try {
    const { doctorId } = req.body;
    const userId = req.user.id;

    // Remove the doctor from favorites
    await Favorite.findOneAndDelete({ user: userId, doctor: doctorId });

    // Send the success response
    res.status(200).json({
      status: "success",
      data: "Doctor has been removed from favorites",
    });
  } catch (error) {
    next(new AppError("Doctor is not difined", 404));
  }
};
