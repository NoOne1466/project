const express = require("express");
const reviewUsersController = require("../controllers/reviewUsersController");
const authController = require("../controllers/authController");
const ReviewUsers = require("../models/reviewUsersModel");
const Doctor = require("../models/doctorModel");
const User = require("../models/userModel");

const router = express.Router({ mergeParams: true });

router
  .route("/")
  .get(
    authController.protect,
    authController.restrictTo("User"),
    reviewUsersController.getAllReviews
  )
  .post(
    authController.protect,
    authController.restrictTo("User"),
    reviewUsersController.setDoctorUserIds,
    reviewUsersController.createNewReview
  );

router
  .route("/:id")
  .patch(reviewUsersController.updateReview)
  .delete(reviewUsersController.deleteReview);

module.exports = router;
